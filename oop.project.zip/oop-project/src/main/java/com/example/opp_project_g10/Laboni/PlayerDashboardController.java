package com.example.opp_project_g10.Laboni;

public class PlayerDashboardController
{
    @javafx.fxml.FXML
    private TextField emergencyContactTextField;
    @javafx.fxml.FXML
    private DatePicker dateFilterDP;
    @javafx.fxml.FXML
    private TableView<MatchFixture> matchTableTV;
    @javafx.fxml.FXML
    private TextField quantityFieldTF;
    @javafx.fxml.FXML
    private TextArea equipmentReasonFieldTA;
    @javafx.fxml.FXML
    private TextArea reasonFieldTA;
    @javafx.fxml.FXML
    private DatePicker startDatePicker;
    @javafx.fxml.FXML
    private TableView matchTableTableView;
    @javafx.fxml.FXML
    private TextField injuryTextField;
    @javafx.fxml.FXML
    private TableView medicalTableView;
    @javafx.fxml.FXML
    private RowConstraints Weight;
    @javafx.fxml.FXML
    private TextField weightTextField;
    @javafx.fxml.FXML
    private DatePicker endDatePicker;
    @javafx.fxml.FXML
    private ComboBox leaveType;
    @javafx.fxml.FXML
    private TableView<MedicalRecord> medicalRecordTableViewTableView;

    private final PlayerService playerService = new PlayerService();
    private Player currentPlayer;
    @javafx.fxml.FXML
    public void initialize() {
        setupLeaveTypeComboBox();
        setupMatchTable();
        setupMedicalTable();
        configureDatePickers();
    }
    public void setPlayer(Player player) {
        this.currentPlayer = player;
        loadPlayerData();
    }

    private void loadPlayerData() {
        // match fixtures
        matchTableTV.setItems(FXCollections.observableArrayList(
                playerService.getMatchFixtures(currentPlayer.getTeamId(),null)
        ));

        // medical records
        medicalTableView.setItems(FXCollections.observableArrayList(
                playerService.getMedicalRecords(currentPlayer.getId())
        ));

        // profile data
        emergencyContactTextField.setText(currentPlayer.getEmergencyContact());
    }

    private void setupLeaveTypeComboBox() {
        leaveType.setItems(FXCollections.observableArrayList(
                "Medical Leave", "Personal Leave", "Family Emergency", "Other"
        ));
    }

    private void setupMatchTable() {

        TableColumn<MatchFixture, String> dateCol = new TableColumn<>("Date");
        dateCol.setCellValueFactory(new PropertyValueFactory<>("formattedDate"));

        TableColumn<MatchFixture, String> opponentCol = new TableColumn<>("Opponent");
        opponentCol.setCellValueFactory(new PropertyValueFactory<>("opponent"));

        TableColumn<MatchFixture, String> venueCol = new TableColumn<>("Venue");
        venueCol.setCellValueFactory(new PropertyValueFactory<>("venue"));

        matchTableTV.getColumns().setAll(dateCol, opponentCol, venueCol);
    }

    private void setupMedicalTable() {

        TableColumn<MedicalRecord, String> dateCol = new TableColumn<>("Date");
        dateCol.setCellValueFactory(new PropertyValueFactory<>("formattedDate"));

        TableColumn<MedicalRecord, String> typeCol = new TableColumn<>("Type");
        typeCol.setCellValueFactory(new PropertyValueFactory<>("type"));

        TableColumn<MedicalRecord, String> detailsCol = new TableColumn<>("Details");
        detailsCol.setCellValueFactory(new PropertyValueFactory<>("summary"));

        medicalTableView.getColumns().setAll(dateCol, typeCol, detailsCol);
    }

    private void configureDatePickers() {

        startDatePicker.setDayCellFactory(picker -> new DateCell() {
            public void updateItem(LocalDate date, boolean empty) {
                super.updateItem(date, empty);
                setDisable(empty || date.isBefore(LocalDate.now()));
            }
        });

        endDatePicker.setDayCellFactory(picker -> new DateCell() {
            public void updateItem(LocalDate date, boolean empty) {
                super.updateItem(date, empty);
                setDisable(empty || date.isBefore(startDatePicker.getValue()));
            }
        });

        // date pickers
        startDatePicker.valueProperty().addListener((obs, oldVal, newVal) -> {
            endDatePicker.setValue(newVal.plusDays(1));
            endDatePicker.setDisable(false);
        });
    }


    @FXML
    private void submitFitnessReport() {
        try {
            FitnessReport report = new FitnessReport(
                    Double.parseDouble(weightTextField.getText()),
                    0, // Sleep duration field missing in UI
                    injuryTextField.getText(),
                    currentPlayer.getId()
            );

            if (playerService.submitFitnessReport(report)) {
                showAlert("Success", "Fitness report submitted successfully");
            }
        } catch (NumberFormatException e) {
            showAlert("Error", "Invalid number format in weight field");
        }
    }

    @FXML
    private void submitLeaveRequest() {
        if (leaveType.getValue() == null) {
            showAlert("Error", "Please select a leave type");
            return;
        }

        if (startDatePicker.getValue() == null || endDatePicker.getValue() == null) {
            showAlert("Error", "Please select start and end dates");
            return;
        }

        LeaveRequest request = new LeaveRequest(
                leaveType.getValue(),
                startDatePicker.getValue(),
                endDatePicker.getValue(),
                reasonFieldTA.getText(),
                currentPlayer.getId()
        );

        try {
            playerService.submitLeaveRequest(request);
            showAlert("Success", "Leave request submitted for approval");
            clearLeaveForm();
        } catch (ConflictException e) {
            showAlert("Conflict", e.getMessage());
        }
    }

    @FXML
    private void submitEquipmentRequest() {
        try {
            EquipmentRequest request = new EquipmentRequest(
                    equipmentTypeComboBox.getValue(), // Need to add this ComboBox
                    Integer.parseInt(quantityFieldTF.getText()),
                    equipmentReasonFieldTA.getText(),
                    currentPlayer.getId()
            );

            playerService.submitEquipmentRequest(request);
            showAlert("Success", "Equipment request submitted");
            clearEquipmentForm();
        } catch (NumberFormatException e) {
            showAlert("Error", "Invalid quantity value");
        }
    }

    @FXML
    private void updateProfile() {
        currentPlayer.setEmergencyContact(emergencyContactTextField.getText());
        try {
            playerService.updateProfile(currentPlayer);
            showAlert("Success", "Profile updated successfully");
        } catch (ValidationException e) {
            showAlert("Validation Error", e.getMessage());
        }
    }

    @FXML
    private void filterMatchFixtures() {
        LocalDate filterDate = dateFilterDP.getValue();
        List<MatchFixture> filtered = playerService.getMatchFixtures(
                        currentPlayer.getTeamId(),
                        null
                ).stream()
                .filter(f -> filterDate == null || f.getDate().equals(filterDate))
                .collect(Collectors.toList());

        matchTableTV.setItems(FXCollections.observableArrayList(filtered));
    }

    // Utility Methods
    private void clearLeaveForm() {
        leaveType.getSelectionModel().clearSelection();
        startDatePicker.setValue(null);
        endDatePicker.setValue(null);
        reasonFieldTA.clear();
    }

    private void clearEquipmentForm() {
        quantityFieldTF.clear();
        equipmentReasonFieldTA.clear();
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    // Model Classes
    public static class MatchFixture {
        private LocalDate date;
        private String opponent;
        private String venue;

        public String getFormattedDate() {
            return date.toString();
        }
    }

    public static class MedicalRecord {

        private LocalDate date;
        private String type;
        private String summary;

        public String getFormattedDate() {
            return date.toString();
        }
    }
}
