package com.example.opp_project_g10.Laboni;


public class PlayerService {
    // Goal 1: Training Schedule
    public List<TrainingSchedule> getTrainingSchedule(String playerId) {
        return Database.getTrainingSchedules().stream()
                .filter(s -> s.getPlayerId().equals(playerId))
                .sorted(Comparator.comparing(TrainingSchedule::getDateTime))
                .collect(Collectors.toList());
    }

    // Goal 2: Fitness Report
    public boolean submitFitnessReport(FitnessReport report) {
        if (validateFitnessReport(report)) {
            return Database.saveFitnessReport(report);
        }
        return false;
    }

    private boolean validateFitnessReport(FitnessReport report) {
        return report.getWeight() > 30 &&
                report.getSleepDuration() > 0 &&
                report.getSleepDuration() <= 24;
    }

    // Goal 3: Leave Request
    public LeaveRequest submitLeaveRequest(LeaveRequest request) {
        if (!hasScheduleConflict(request)) {
            request.setStatus("PENDING");
            return Database.saveLeaveRequest(request);
        }
        throw new ConflictException("Schedule conflict detected");
    }

    private boolean hasScheduleConflict(LeaveRequest request) {
        return Database.getTrainingSchedules().stream()
                .anyMatch(s -> s.getPlayerId().equals(request.getPlayerId()) &&
                        s.getDateTime().toLocalDate().isAfter(request.getStartDate().minusDays(1)) &&
                        s.getDateTime().toLocalDate().isBefore(request.getEndDate().plusDays(1)));
    }

    // Goal 4: Match Fixtures
    public List<MatchFixture> getMatchFixtures(String teamId, String competition) {
        return Database.getMatchFixtures().stream()
                .filter(f -> f.getTeamId().equals(teamId))
                .filter(f -> competition == null || competition.isEmpty() ||
                        f.getCompetition().equalsIgnoreCase(competition))
                .sorted(Comparator.comparing(MatchFixture::getDateTime))
                .collect(Collectors.toList());
    }

    // Goal 6: Equipment Request
    public EquipmentRequest submitEquipmentRequest(EquipmentRequest request) {
        if (!hasDuplicateRequest(request)) {
            return Database.saveEquipmentRequest(request);
        }
        throw new DuplicateRequestException("Duplicate equipment request detected");
    }

    private boolean hasDuplicateRequest(EquipmentRequest request) {
        return Database.getEquipmentRequests().stream()
                .anyMatch(r -> r.getPlayerId().equals(request.getPlayerId()) &&
                        r.getEquipmentType().equals(request.getEquipmentType()) &&
                        r.getStatus().equals("PENDING"));
    }

    // Goal 7: Update Profile
    public Player updateProfile(Player player) {
        if (ValidationService.validateProfile(player)) {
            return Database.updatePlayer(player);
        }
        throw new ValidationException("Profile validation failed");
    }

    // Goal 8: Medical Records
    public List<MedicalRecord> getMedicalRecords(String playerId) {
        return Database.getMedicalRecords().stream()
                .filter(r -> r.getPlayerId().equals(playerId))
                .sorted(Comparator.comparing(MedicalRecord::getDate).reversed())
                .collect(Collectors.toList());
    }
}