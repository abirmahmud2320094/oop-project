package com.example.opp_project_g10.Laboni;


public class MedicalService {
    // Goal 9: Injury Report
    public InjuryReport submitInjuryReport(InjuryReport report) {
        if (ValidationService.validateInjuryReport(report)) {
            return Database.saveInjuryReport(report);
        }
        throw new ValidationException("Invalid injury report");
    }

    // Goal 10: Schedule Checkup
    public CheckupSchedule scheduleCheckup(CheckupSchedule schedule) {
        if (!hasConflict(schedule)) {
            NotificationService.notifyPlayers(schedule.getPlayerIds());
            return Database.saveCheckupSchedule(schedule);
        }
        throw new ConflictException("Schedule conflict detected");
    }

    private boolean hasConflict(CheckupSchedule schedule) {
        return Database.getTrainingSchedules().stream()
                .anyMatch(s -> schedule.getPlayerIds().contains(s.getPlayerId()) &&
                        s.getDateTime().equals(schedule.getDateTime()));
    }

    // Goal 11: Medical Clearance
    public MedicalClearance updateMedicalClearance(MedicalClearance clearance) {
        if (medicalService.isValidClearance(clearance)) {
            NotificationService.notifyCoach(clearance.getPlayerId());
            return Database.saveMedicalClearance(clearance);
        }
        throw new MedicalException("Invalid clearance status");
    }

    // Goal 12: Medicine Management
    public Medicine updateMedicineStock(Medicine medicine) {
        if (medicine.getQuantity() >= 0 &&
                medicine.getExpiryDate().isAfter(LocalDate.now())) {
            return Database.updateMedicine(medicine);
        }
        throw new ValidationException("Invalid medicine data");
    }

    // Goal 13: Generate Reports
    public MedicalReport generateReport(ReportRequest request) {
        MedicalReport report = ReportGenerator.createReport(request);
        if (request.getFormat().equals("PDF")) {
            return PdfExporter.export(report);
        }
        return report;
    }

    // Goal 14: Emergency Report
    public EmergencyReport logEmergency(EmergencyReport report) {
        report.setTimestamp(LocalDateTime.now());
        NotificationService.alertMedicalTeam();
        return Database.saveEmergencyReport(report);
    }

    // Goal 15: Coach Communication
    public void sendToCoach(MedicalMessage message) {
        if (ValidationService.validateCoachAssignment(message)) {
            Database.saveMedicalMessage(message);
            NotificationService.notifyCoach(message.getCoachId());
        }
    }

    // Goal 16: Recovery Tracking
    public RecoveryProgress updateRecoveryProgress(RecoveryProgress progress) {
        progress.setDate(LocalDate.now());
        return Database.saveRecoveryProgress(progress);
    }

    public static class InjuryReport {
    }
}