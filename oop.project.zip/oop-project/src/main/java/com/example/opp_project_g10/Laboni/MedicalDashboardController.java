package com.example.opp_project_g10.Laboni;

public class MedicalDashboardController
{
    @javafx.fxml.FXML
    private TextArea messageFieldTA;
    @javafx.fxml.FXML
    private TableColumn Player;
    @javafx.fxml.FXML
    private TableColumn IncidentTC;
    @javafx.fxml.FXML
    private ToggleButton clearanceGroupTB;
    @javafx.fxml.FXML
    private ComboBox doctorSelectionCB;
    @javafx.fxml.FXML
    private TableColumn ExpiryDateTC;
    @javafx.fxml.FXML
    private TableColumn InjuryTypeTC;
    @javafx.fxml.FXML
    private TableColumn QuantityTC;
    @javafx.fxml.FXML
    private TableView injuryTableView;
    @javafx.fxml.FXML
    private TableColumn DateTC;
    @javafx.fxml.FXML
    private TableColumn MedicineTC;
    @javafx.fxml.FXML
    private TableColumn PlayerTC;
    @javafx.fxml.FXML
    private TableColumn TimeTC;
    @javafx.fxml.FXML
    private ListView playerSelection;
    @javafx.fxml.FXML
    private ComboBox playerSelectorCB;
    @javafx.fxml.FXML
    private ComboBox reportType;
    @javafx.fxml.FXML
    private DatePicker checkupDateDP;
    @javafx.fxml.FXML
    private ComboBox recoveryPlayerCB;
    @javafx.fxml.FXML
    private ComboBox coachSelectorCB;
    @javafx.fxml.FXML
    private TableView emergencyTableView;
    @javafx.fxml.FXML
    private TableView medicineTableView;
    @javafx.fxml.FXML
    private LineChart recoveryChartLC;
    @javafx.fxml.FXML
    private TableColumn SeverityTC;

    @javafx.fxml.FXML
    public void initialize() {
    }

    @javafx.fxml.FXML
    public void showInjuryFormOnAction(ActionEvent actionEvent) {
    }

    @javafx.fxml.FXML
    public void generateReportOnAction(ActionEvent actionEvent) {
    }

    @javafx.fxml.FXML
    public void updateClearanceOnAction(ActionEvent actionEvent) {
    }

    @javafx.fxml.FXML
    public void updateRecoveryOnAction(ActionEvent actionEvent) {
    }

    @javafx.fxml.FXML
    public void showMedicineFormOnAction(ActionEvent actionEvent) {
    }

    @javafx.fxml.FXML
    public void sendToCoachOnAction(ActionEvent actionEvent) {
    }

    @javafx.fxml.FXML
    public void scheduleCheckupOnAction(ActionEvent actionEvent) {
    }
}